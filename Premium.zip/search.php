<?php
include './hsn-inc/func.php';
$title='Download Game Dan Aplikasi Gratis';
$q=$_GET['q'];
$c=ucwords(str_replace('-',' ',$q));
include './hsn-inc/header.php';
echo '<div class="ngiri">
<div class="r"><b> Hasil Unggulan &quot;'.$c.'&quot; </b></div>
<div class="file">
<table class="otable" width="100%">
<tbody>
';
$grab=grab('https://www.9apps.co.id/search/tag-'.$q.'-1/');
$hasil=potong('<ul class="list">','</ul>',$grab);
preg_match_all('#<li class=\"item\">(.*?)</li>#s',$hasil,$array);
$list=$array[1];
for($i=0;$i<count($list);$i++){
$ini=$list[$i];
$link=potong('href="','"',$ini);
$img=potong('dataimg="','"',$ini);
$name=potong('<p class="name">','</p>',$ini);
$size=potong('<span class="size">','</span>',$ini);
$type=potong('<span class="type">','</span>',$ini);
$down='/jump/down/'.potong('href="/jump/down/','"',$ini);
$download='https://www.9apps.co.id'.$down;
echo '<tr>
<td class="vithumb" width="100px">
<img src="'.$img.'" title="'.$name.' Icon" width="100px">
</td> 
<td class="videsc">
<a href="'.$link.'">'.$name.'</a><br />
<span class="labels">'.$size.'</span>
<span class="labels">'.$type.'</span>
</td>
</tr>
';
}
echo '</tbody>
</table>
</div>
</div>';
echo '<div class="nganan">
<div class="r"><b> Hasil Lainnya </b></div>
<div class="file">
<table class="otable" width="100%">
<tbody>
';
$hasil=potong('<h2 class="title">Hasil pencarian lebih </h2>','</ul>',$grab);
preg_match_all('#<li class=\"item\">(.*?)</li>#s',$hasil,$array);
$list=$array[1];
for($i=0;$i<count($list);$i++){
$ini=$list[$i];
$link=potong('href="','"',$ini);
$img=potong('dataimg="','"',$ini);
$name=potong('<p class="name">','</p>',$ini);
$size=potong('<span class="size">','</span>',$ini);
$type=potong('<span class="type">','</span>',$ini);
$down='/jump/down/'.potong('href="/jump/down/','"',$ini);
$download='https://www.9apps.co.id'.$down;
echo '<tr>
<td class="vithumb" width="100px">
<img src="'.$img.'" title="'.$name.' Icon" width="100px">
</td> 
<td class="videsc">
<a href="'.$link.'">'.$name.'</a><br />
<span class="labels">'.$size.'</span>
<span class="labels">'.$type.'</span>
</td>
</tr>
';
}
echo '</tbody>
</table>
</div>
</div>';
include './hsn-inc/footer.php';
?>