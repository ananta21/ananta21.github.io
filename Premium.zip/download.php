<?php
if($_GET['mode']=='direct'){
header('Location:https://www.9apps.co.id/jump/down/'.$_GET['pack'].'/'.$_GET['type'].'/?f='.$_GET['f'].'&pid='.$_GET['pid'].'&page='.$_GET['page'].'');
}else{
$h=get_headers('https://www.9apps.co.id/jump/down/'.$_GET['pack'].'/'.$_GET['type'].'/?f='.$_GET['f'].'&pid='.$_GET['pid'].'&page='.$_GET['page'].'',TRUE) or die ('Kesalahan Server!');
header('Content-Type:application/vnd.android.package-archive');
header('Content-Disposition:attachment;filename="'.$_GET['pack'].'.apk"');
header('Content-Length:'.$h['Content-Length'][1].'');
readfile($h['Location'][1]);
}
exit;
?>
