<?php
if(!empty($_GET['q'])){
$q=preg_replace('#([^a-zA-Z0-9-]*?)#','',str_replace(' ','-',$_GET['q']));
$url='//'.$_SERVER['HTTP_HOST'].'/download/'.$q.'/';
}else{
$url='//'.$_SERVER['HTTP_HOST'];
}
header('HTTP/1.1 301 Moved Permanently');
header('Location:'.$url);
?>