<?php
include './hsn-inc/func.php';
$perm=$_GET['perm'];
if($_GET['type']=='apps'){
$grab=grab('https://www.9apps.co.id/android-apps/'.$perm.'/');
}else{
$grab=grab('https://www.9apps.co.id/android-games/'.$perm.'/');
}
$img=potong('<img class="lazy" dataimg="','"',$grab);
$name=potong('<span itemprop="name">','</span>',$grab);
$rate=potong('itemprop="ratingValue">','</span>',$grab);
$rating=potong('<span itemprop="ratingCount">','</span>',$grab);
$ot=potong('<p class="other">','</p>',$grab);
$type=explode('<span>',$ot);
$type=strip_tags($type[0]);
$size=potong('<div class="size">','</div>',$grab);
$down=potong('href="/jump/down','"',$grab);
$down=preg_replace('#\/([^/]*?)\/(app|game)\/#s','/cdn/$2/$1.apk',$down);
$desc=potong('<p class="text">','</p>',$grab);
$versi=potong('Versi:</span> ','</p>',$grab);
$ul=potong('<ul>','</ul>',$grab);
preg_match_all('#<img dataimg=\"([^"]*?)\"#s',$ul,$list);
$preview=$list[1];
$title='Download '.$name.'.apk Versi '.$versi.' Gratis';
include './hsn-inc/header.php';
echo '<div class="ngiri"><div class="title_a"><b>'.$name.' </b>
<br>'.$type.'</div>
<div class="menu">
<div align="center">
<img src="'.$img.'" alt="'.$name.' Logo" width="50%">
</div>
<table width="100%">
<tbody>
<tr>
<td>Nama</td>
<td>:</td>
<td>'.$name.'</td>
</tr>
<tr>
<td>Versi</td>
<td>:</td>
<td>'.$versi.'</td>
</tr>
<tr>
<td>Rating</td>
<td>:</td>
<td>'.$rate.' ('.$rating.')</td>
</tr>
</tbody>
</table>
</div>
<div class="r">Deskripsi</div>
<div class="file">
<p>'.$desc.'</p>
</div>
<div class="r">Screenshot</div>
<div class="menu">
';
$c=0;
foreach($preview as $im){
$c++;
echo '<img src="'.$im.'" alt="'.$name.' Screenshoot '.$c.'" width="32%"> ';
}
echo '</div>
<div class="r">Link Download</div>
<div class="menu">
<a href="'.$down.'"><div class="dbutton">Download ('.$size.')</div></a>
<a href="'.str_ireplace('/cdn/','/cdn2/',$down).'" target="_blank"><div class="dbutton">Download (Server II)</div></a>
</div>
</div>';
echo '<div class="nganan">
<div class="r">Pengguna Juga Mengunduh</div>
<div class="file">
<table class="otable" width="100%">
<tbody>
';
$related=potong('<ul class="reco-list">','</ul>',$grab);
$list=explode('<li class="item">',$related);
for($i=1;$i<count($list);$i++){
$ini=$list[$i];
$link=potong('href="','"',$ini);
$img=potong('dataimg="','"',$ini);
$name=potong('detail-name-font">','</p>',$ini);
$down=potong('href="/jump/down','"',$ini);
$down=preg_replace('#\/([^/]*?)\/(app|game)\/#s','/cdn/$2/$1.apk',$down);
echo '<tr>
<td class="vithumb" width="100px">
<img src="'.$img.'" title="'.$name.' Icon" width="100px">
</td> 
<td class="videsc">
<a href="'.$link.'">'.$name.'</a><br />
<a href="'.$down.'"><span class="labels">Download</span>
</a>
</td>
</tr>
';
}
echo '
</tbody>
</table>
</div>
</div>
';
include './hsn-inc/footer.php';
?>