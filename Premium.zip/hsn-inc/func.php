<?php
function ambil($url){
// Start cURL
       $ip=$_SERVER['REMOTE_ADDR'];
//Geting User IP
		$setUA = 'Mozilla/5.0 (Linux; U; Android 4.4.2; zh-cn; spc; Android/4.4.2; Release/09.16.2015) AppleWebKit/534.30 (KHTML, like Gecko) Mobile Safari/534.30';
// User Agent
		$ch = curl_init();
// calling cURL
		curl_setopt($ch, CURLOPT_URL, $url);
// Set URL
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// set return Transfer
		curl_setopt($ch, CURLOPT_REFERER, $url);
// Set HTTP Referer
		curl_setopt($ch, CURLOPT_USERAGENT, $setUA); // Set UA curl_setopt($ch,CURLOPT_HTTPHEADER,array("REMOTE_ADDR:$ip","HTTP_X_FORWARDED_FOR:$ip"));
// Set IP Header
		$ret = curl_exec($ch);
// exec CURL
		curl_close($ch);
// closing cURL
		return $ret;
// Return
	}
function grab($url){
$base=base64_encode($url);
$path=__DIR__.'/cache/'.$base.'.grb';
if(file_exists($path)){
$time=filemtime($path)+60*60;
if($time<time()){
$ret=file_get_contents($path);
}else{
$ret=ambil($url);
file_put_contents($path,$ret);
}
}else{
$ret=ambil($url);
file_put_contents($path,$ret);
}
return $ret;
}
function potong($s,$e,$c){
$ex=explode($s,$c);
$ex=explode($e,$ex[1]);
return $ex[0];
}
?>