<?php
echo '<div class="kaki1">
'.date('D,d M Y H:i',time()+60*60*7).'
</div>
<div class="kaki2">
&copy; '.date('Y').' <strong>Hasan Wap</strong>
</div>
</body>
</html>';
?>