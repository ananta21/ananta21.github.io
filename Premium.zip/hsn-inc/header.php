<?php
echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML Basic 1.1//EN" "http://www.w3.org/TR/xhtml-basic/xhtml-basic11.dtd"><html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8;" />

<title>'.$title.' - Hasan WAP</title>
<meta name="description" content="'.$title.' - '.$description.'" />
<meta name="keywords" content="'.$keywords.'">
 
<meta http-equiv="cache-control" content="max-age=0" />
<meta http-equiv="cache-control" content="no-cache" />
<meta http-equiv="expires" content="0" />
<meta http-equiv="expires" content="" />
<meta http-equiv="pragma" content="no-cache" />

<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta name="geo.placename" content="Indonesia" />
<meta name="geo.position" content="-7.226868,112.761719" />
<meta name="geo.region" content="id" />
<meta name="spiders" content="all" />
<meta name="googlebot" content="All, index, follow" />
<meta name="robots" content="All, index, follow" />
<meta name="msnbot" content="All, index, follow" />
<meta content="follow, all" name="robots" />
<meta content="follow, all" name="seznambot" />

<meta content="follow, all" name="Slurp" />
<meta content="follow, all" name="ia_archiver" />
<meta content="follow, all" name="Baiduspider" />
<meta content="follow, all" name="BecomeBot" />
<meta content="follow, all" name="Bingbot" />
<meta content="follow, all" name="btbot" />
<meta content="follow, all" name="Dotbot" />
<meta content="follow, all" name="Yeti" />
<meta content="follow, all" name="Teoma" />
<meta content="follow, all" name="Yandex" />
<meta content="follow, all" name="FAST-WebCrawler" />
<meta content="follow, all" name="FindLinks" />
<meta content="follow, all" name="FyberSpider" />
<meta content="follow, all" name="008" />
<meta name="generator" content="Hasan Team" />
<meta name="distribution" content="global" />
<link href="https://fonts.googleapis.com/css?family=Encode+Sans+Semi+Condensed" rel="stylesheet">
<link rel="stylesheet" href="/hsn-asset/style.css" type="text/css" />
</head>
<body>
<div class="header" align="center">
<a href="/"><img src="/hsn-asset/hasanwap.png" alt="Hasan WAP"></a>
</div><div id="wasu">
<div class="content-wrapper">';
echo '<table border="0" class="tableup"><tbody><tr>
<td class="notd">
<a href="/games"> <div style="height:100%;width:100%">
<img src="//d30y9cdsu7xlg0.cloudfront.net/png/23385-200.png" height="35px" alt="Games"  title="Games"><br />Games</div></a></td>
<td class="notd"> <a href="/apps">
<div style="height:100%;width:100%">
 <img src="//maxcdn.icons8.com/Share/icon/Programming//software_box1600.png" height="35px" alt="Apps"  title="Apps"><br />Apps</div></a></td>
</tr></tbody></table>

<div class="search-input">
<form method="get" action="/search">
<center>
<input type="text" name="q" value="" width="80%" class="ui-autocomplete-input" autocomplete="off"><input type="submit" value="Search"/>
</form>
</center>
</div>
<div class="infocoy"><img src="/hsn-asset/info.png" alt="info icon">Dapatkan game dan aplikasi android terbaru hanya di <b>http://'.$_SERVER['HTTP_HOST'].'</b>!</div>
';
?>
