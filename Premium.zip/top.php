<?php
include './hsn-inc/func.php';
$page=is_numeric($_GET['page'])?trim($_GET['page']):'1';
if($_GET['type']=='apps'){
$title='Aplikasi Android Teratas Halaman : '.$page.'';
include './hsn-inc/header.php';
echo '<div class="r"><b> Top Android Apps : '.$page.' </b></div>
';
$grab=grab('https://www.9apps.co.id/top-android-apps-'.$page.'/');
}else{
$title='Games Android Teratas Halaman : '.$page.'';
include './hsn-inc/header.php';
echo '<div class="r"><b> Top Android Games : '.$page.' </b></div>
';
$grab=grab('https://www.9apps.co.id/top-android-games-'.$page.'/');
}
$hasil=potong('<ul class="list">','</ul>',$grab);
preg_match_all('#<li class=\"item\">(.*?)</li>#s',$hasil,$array);
$list=$array[1];
echo '<div class="ngiri">
<div class="file">
<table class="otable" width="100%">
<tbody>
';
for($i=0;$i<20;$i++){
$ini=$list[$i];
$link=potong('href="','"',$ini);
$img=potong('dataimg="','"',$ini);
$name=potong('<p class="name">','</p>',$ini);
$size=potong('<span class="size">','</span>',$ini);
$type=potong('<span class="type">','</span>',$ini);
$down='/jump/down/'.potong('href="/jump/down/','"',$ini);
$download='https://www.9apps.co.id'.$down;
echo '<tr>
<td class="vithumb" width="100px">
<img src="'.$img.'" title="'.$name.' Icon" width="100px">
</td> 
<td class="videsc">
<a href="'.$link.'">'.$name.'</a><br />
<span class="labels">'.$size.'</span>
<span class="labels">'.$type.'</span>
</td>
</tr>
';
}
echo '</tbody>
</table>
</div>
</div>';
echo '<div class="nganan">
<div class="file">
<table class="otable" width="100%">
<tbody>
';
for($i=21;$i<count($list);$i++){
$ini=$list[$i];
$link=potong('href="','"',$ini);
$img=potong('dataimg="','"',$ini);
$name=potong('<p class="name">','</p>',$ini);
$size=potong('<span class="size">','</span>',$ini);
$type=potong('<span class="type">','</span>',$ini);
$down='/jump/down/'.potong('href="/jump/down/','"',$ini);
$download='https://www.9apps.co.id'.$down;
echo '<tr>
<td class="vithumb" width="100px">
<img src="'.$img.'" title="'.$name.' Icon" width="100px">
</td> 
<td class="videsc">
<a href="'.$link.'">'.$name.'</a><br />
<span class="labels">'.$size.'</span>
<span class="labels">'.$type.'</span>
</td>
</tr>
';
}
echo '</tbody>
</table>
</div>
</div>
<div class="vagination">
';
if($_GET['type']=='apps'){
if($page>1){
echo '
<a href="/top-apps?page='.($page-1).'"> ← PREV </a>
';
}
echo '<a href="#">'.$page.'</a>';
if(!empty($list)){
echo '<a href="/top-apps?page='.($page+1).'"> NEXT → </a>
';
}
}else{
if($page>1){
echo '
<a href="/top-games?page='.($page-1).'"> ← PREV </a>
';
}
echo '<a href="#">'.$page.'</a>';
if(!empty($list)){
echo '<a href="/top-games?page='.($page+1).'"> NEXT → </a>
';
}
}
echo '
</div>
';
include './hsn-inc/footer.php';
?>